

package com.mycompany.metodos_abier_cerra;

import java.util.Scanner;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

/**
 *
 * @author Tonin
 * @version 2
 */
public class Metodos_Abier_Cerra {

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        Metodos_Abier_Cerra metodos = new Metodos_Abier_Cerra();
        int opcion;
        do {
            System.out.println("\nSeleccione un método:");
            System.out.println("");
            System.out.println("Metodos Cerrados ------------------|");
            System.out.println("|    1. Método por Biseccion");
            System.out.println("|    2. Método por Falsa Posición");
            System.out.println("");
            System.out.println("Metodos Abiertos ------------------|");
            System.out.println("|    3. Método por Punto Fijo");
            System.out.println("|    4. Método por Newton-Raphson");
            System.out.println("|    5. Método por la Secante");
            System.out.println("Metodos Modificados ------------------|");
            System.out.println("|    6. Método Newton-Raphson Modificado");
            System.out.println("|    7. Método la Secante Modificada");
            System.out.println("");
            System.out.println("8. Ayuda");
            System.out.println("9. Salir");
            System.out.print("--->");
            opcion = scanner.nextInt();
            scanner.nextLine();
            double Tol;
            double a;
            String f;
            double b;
            double punto;
            String fP;
            switch (opcion) {
                case 1:
                    System.out.println("________________________");
                    System.out.println("Introduce una funcion: ");
                    f = scanner.nextLine();
                    System.out.println("________________________");
                    System.out.println("Ingrese un punto(a): ");
                    a = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Ingrese un punto (b): ");
                    b = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.MetBiseccion(f,a,b,Tol);
                    break;
                case 2:
                    System.out.println("________________________");
                    System.out.println("Introduce una funcion: ");
                    f = scanner.nextLine();
                    System.out.println("________________________");
                    System.out.println("Ingrese un punto(a): ");
                    a = scanner.nextDouble();
                    
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Ingrese un punto (b): ");
                    b = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.metFalsePosicion(f,a,b,Tol);
                    break;
                case 3:
                    System.out.println("________________________");
                    System.out.println("Introduce una funcion f(x): ");
                    String fx = scanner.nextLine();     
                    System.out.println("________________________");
                    System.out.println("Introduce una funcion g(x): ");
                    System.out.println("________________________");
                    String fg = scanner.nextLine();
                    System.out.println("Ingrese un punto: ");
                    punto = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.metPuntoFijo(fx,fg,punto,Tol);
                case 4:
                    System.out.println("________________________");
                    System.out.println("Introduce una funcion f(x): ");
                    f = scanner.nextLine();              
                    System.out.println("________________________");
                    System.out.println("Introduce su f'(x): ");
                    fP = scanner.nextLine();
                    System.out.println("________________________");
                    System.out.println("Ingrese un punto: ");
                    punto = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.metNewtonRapson(f,fP,punto,Tol);
                    break;
                case 5:
                    System.out.println("________________________");
                    System.out.println("Introduce un funcion f(x): ");
                    f = scanner.nextLine();
                    System.out.println("________________________");
                    System.out.println("Ingrese tu primer punto(x1): ");
                    a = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Ingrese un punto(x0): ");
                    b = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.metSecante(f,a,b,Tol);
                    break;
                case 6:
                    System.out.println("Introduce una funcion f(x): ");
                    System.out.println("________________________");
                    f = scanner.nextLine();              
                    System.out.println("Introduce f'(x): ");
                    System.out.println("________________________");
                    fP = scanner.nextLine();
                    System.out.println("Introduce la 2 derivada f''(x): ");
                    String fO2 = scanner.nextLine();
                    System.out.println("Ingrese un punto: ");
                    punto = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.metNewtonRapsonModificado(f,fP,fO2,punto,Tol);
                    break;
                case 7:
                    System.out.println("________________________");
                    System.out.println("Introduce una funcion f(x): ");
                    f = scanner.nextLine();              
                    System.out.println("________________________");
                    System.out.println("Introduce f'(x): ");
                    fP = scanner.nextLine();
                    System.out.println("________________________");
                    System.out.println("Ingrese un punto: ");
                    a = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Ingrese un punto: ");
                    b = scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    System.out.println("Tolerancia: ");
                    Tol=scanner.nextDouble();
                    scanner.nextLine();//consumir caracter de linea
                    metodos.metSecanteModificada(f,fP,a,b,Tol);
                    break;
                case 8 :
                   
                    System.out.println("""
                                       Addition: 2 + 2
                                       Subtraction (+): 2 - 2
                                       Multiplication(-): 2 * 2
                                       Division (/): 2 / 2
                                       Exponentation (^): 2 ^ 2
                                       Unary Minus,Plus (Sign Operators): +2 - (-2)
                                       Modulo (%): 2 % 2""");
                    System.out.println("Funcion exponencial(exp()): exp(2*x)");
                    
                    break;
                case 9:
                    
                    
                    break;
                case 10:
                    System.out.println("https://stats.fm/ingmutablename");
                    break;
                    
                    
                default:
                    throw new AssertionError();
            }

    }while (opcion != 9);  
       scanner.close();
    }
    
    public void MetBiseccion(String f, double a, double b, double Tol) throws Exception {
        ExpressionBuilder expBuild = new ExpressionBuilder(f).variable("x");
        Expression exp = expBuild.build();

        excepciones(f, a, b);

        double error = 100;
        System.out.println("Tabla");
        System.out.println("_____________________________________________________________________________________");

        System.out.printf("%5s %10.4s %10.4s %10.4s %10.4s %10.4s\n", "i", "a", "b", "c", "Fc", "Error");
        int i = 0;
        double x0 = 0;
        while (error > Tol) {
            double fa = exp.setVariable("x", a).evaluate();

            double xl = (a + b) / 2;
            double fc = exp.setVariable("x", xl).evaluate();

            error = Math.abs((x0 - xl)) * 100;
            x0 = xl;

            if (i == 0) {
                System.out.printf("%5d %10.4f %10.4f %10.4f %10.4f %10.4s\n", i, a, b, xl, fc, "----");
                error = 100;
            } else
                System.out.printf("%5d %10.4f %10.5f %10.4f %10.4f %10.4f\n", i, a, b, xl, fc, error);

            if (fa * fc < 0) {
                b = xl;
            } else {
                a = xl;
            }
            i++;
        }
        System.out.println("_____________________________________________________________________________________");

        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x0);

    }
  
    public void metFalsePosicion(String f, double a, double b, double Tol) throws Exception {
        Expression exp = new ExpressionBuilder(f).variable("x").build();

        excepciones(f, a, b);

        double error = 100;
        double x0 = 0;
        System.out.println("Tabla");
        System.out.println("_____________________________________________________________________________________");
        System.out.printf("%5s %10.5s %10.5s %10.5s %10.5s %10.5s\n", "i", "a", "b", "c", "Fc", "Error%");

        int i = 0;
        while (error > Tol) {
            double fa = exp.setVariable("x", a).evaluate();
            double fb = exp.setVariable("x", b).evaluate();

            double xl = a - (fa) * ((b - a) / (fb - fa));

            double fc = exp.setVariable("x", xl).evaluate();

            error = Math.abs((x0 - xl) * 100);

            x0 = xl;

            if (i == 0) {
                System.out.printf("%5d %10.5f %10.5f %10.5f %10.5f %10.5s\n", i, a, b, xl, fc, "----");
                error = 100;
            } else {
                System.out.printf("%5d %10.5f %10.5f %10.5f %10.5f %10.5f\n", i, a, b, xl, fc, error);
            }

            if (fa * fc < 0) {
                b = xl;
            } else {
                a = xl;
            }

            i++;
        }
        System.out.println("_____________________________________________________________________________________");

        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x0);
    }
    

    public void metPuntoFijo(String Fx, String fg, double x, double Tol) throws Exception {
        Expression expG = new ExpressionBuilder(fg).variable("x").build();
        Expression expX = new ExpressionBuilder(Fx).variable("x").build();

        double error = 100;
        double x0 = x;
        System.out.println("Tabla");
        System.out.println("_____________________________________________________________________________________");
        System.out.printf("%5s %10.5s %10.5s %15s %10.5s \n", "i", "xi", "xi+1", "f(xi+1)", "Error%");
        int i = 0;
        while (error > Tol) {
            double xl = expG.setVariable("x", x0).evaluate();
            double fx = expX.setVariable("x", xl).evaluate();

            error = (Math.abs((xl - x0) / xl)) * 100;
            if (i == 0) {
                System.out.printf("%5d %10.5s %10.5s %15f %10.5s\n", i, x0, xl, fx, "----");
            } else {
                System.out.printf("%5d %10.5f %10.5f %15f %10.5f\n", i, x0, xl, fx, error);
            }
            x0 = xl;
            i++;
        }
        System.out.println("_____________________________________________________________________________________");

        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x0);
    }


    public void metNewtonRapson(String f, String derivative, double x, double Tol) throws Exception {
        Expression exp = new ExpressionBuilder(f).variable("x").build();
        Expression expDerivative = new ExpressionBuilder(derivative).variable("x").build();

        if (expDerivative.setVariable("x", x).evaluate() == 0) {
            throw new Exception("Damn bro dividir entre 0??. Estas rompiendo los mandamientos de las matematicas");
        }

        double error = 100;
        double x0 = x;
        System.out.println("Tablita");
        System.out.println("_____________________________________________________________________________________");
        System.out.printf("%5s %15s %15s %15s %10.5s \n", "i", "xi", "xi+1", "f(xi+1)", "Error%");
        int i = 0;
        while (error > Tol) {
            double fx = exp.setVariable("x", x0).evaluate();
            double fxDerivative = expDerivative.setVariable("x", x0).evaluate();

            double xl = x0 - (fx / fxDerivative);

            error = (Math.abs((xl - x0) / xl)) * 100;

            if (i == 0) {
                System.out.printf("%5d %15s %15s %15f %10.5s\n", i, x0, xl, fx, "----");
            } else {
                System.out.printf("%5d %15f %15f %15f %10.5f\n", i, x0, xl, fx, error);
            }

            x0 = xl;
            i++;
        }
        System.out.println("_____________________________________________________________________________________");

        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x0);
    }
    
    public void metSecante(String f, double x0, double x1, double Tol) throws Exception {
        Expression exp = new ExpressionBuilder(f).variable("x").build();
        double error = 100;
        System.out.println("Tabla");
        System.out.println("_____________________________________________________________________________________");
        System.out.printf("%5s %15s %15s %15s %15s %10.5s \n", "i", "xi-1", "xi", "xi+1", "f(xi+1)", "Error%");
        int i = 0;
        while (error > Tol) {
            double fx0 = exp.setVariable("x", x0).evaluate();
            double fx1 = exp.setVariable("x", x1).evaluate();

            double xc = x1 - ((fx1 * (x1 - x0)) / (fx1 - fx0));
            double fxc = exp.setVariable("x", xc).evaluate();

            error = (Math.abs((xc - x1) / xc)) * 100;

            if (i == 0) {
                System.out.printf("%5d %15s %15s %15f %15f %10.5s\n", i, x0, x1, xc, fxc, "----");
            } else {
                System.out.printf("%5d %15f %15f %15f %15f %10.5f\n", i, x0, x1, xc, fxc, error);
            }

            x0 = x1;
            x1 = xc;
            i++;
        }
        System.out.println("_____________________________________________________________________________________");
        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x0);
    }

    public void metNewtonRapsonModificado(String f, String fP, String fO2, double x,double Tol) throws Exception {
        Expression func = new ExpressionBuilder(f).variable("x").build();
        Expression derivativeFunc = new ExpressionBuilder(fP).variable("x").build();
        Expression secondDerivativeFunc = new ExpressionBuilder(fO2).variable("x").build();

        double error = 100, x0 = x;
        System.out.println("Tablita");

        System.out.println("_____________________________________________________________________________________");
        System.out.printf("%5s %15s %15s %20s %10.5s \n", "i", "xi", "xi+1", "f(xi+1)", "Error%");
        int i = 0;

        while (error > Tol) {
            double fx = func.setVariable("x", x0).evaluate();
            double fxDerivative = derivativeFunc.setVariable("x", x0).evaluate();
            double fxSecondDerivative = secondDerivativeFunc.setVariable("x", x0).evaluate();

            double xl = x0
                    - ((fx * fxDerivative) / (Math.pow(fxDerivative, 2) - (fx * fxSecondDerivative)));

            error = (Math.abs((xl - x0) / xl)) * 100;

            if (i == 0) {
                System.out.printf("%5d %15f %15f %20f %10.5s\n", i, x0, xl, fx, "----");
            } else {
                System.out.printf("%5d %15f %15f %20f %10.5f\n", i, x0, xl, fx, error);
            }

            x0 = xl;
            i++;
        }
        System.out.println("_____________________________________________________________________________________");
        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x0);
    }

    
    public void metSecanteModificada(String f, String fP, double x0, double x1, double Tol)
            throws Exception {
        Expression func = new ExpressionBuilder(f).variable("x").build();
        Expression derivativeFunc = new ExpressionBuilder(fP).variable("x").build();
        double error = 100;
        System.out.println("Tabla");

        
        System.out.println("_____________________________________________________________________________________");
        System.out.printf("%5s %15s %15s %15s %15s %10.5s \n", "i", "xi-1", "xi", "xi+1", "f(xi+1)", "Error%");
                int i = 0;

        while (error > Tol) {
            
            double fx0 = func.setVariable("x", x0).evaluate();
            double fxDerivative0 = derivativeFunc.setVariable("x", x0).evaluate();
            double u0 = fx0 / fxDerivative0;

            
            double fx1 = func.setVariable("x", x1).evaluate();
            double fxDerivative1 = derivativeFunc.setVariable("x", x1).evaluate();
            double u1 = fx1 / fxDerivative1;

           
            double xc = x1 - ((u1 * (x1 - x0)) / (u1 - u0));
            double fxc = func.setVariable("x", xc).evaluate();

            error = (Math.abs((xc - x1) / xc)) * 100;

          
            if (i == 0) {
                System.out.printf("%5d %15s %15s %15f %15f %10.5s\n", i, x0, x1, xc, fxc, "----");
            } else {
                System.out.printf("%5d %15f %15f %15f %15f %10.5f\n", i, x0, x1, xc, fxc, error);
            }

            x0 = x1;
            x1 = xc;
            i++;
        }
        System.out.println("_____________________________________________________________________________________");
        System.out.println("");
        
        System.out.printf("La raíz es: %.4E\n", x0);
    }
    
    
    
    public boolean excepciones(String f, double a, double b) throws Exception {
        Expression exp = new ExpressionBuilder(f).variable("x").build();

        double fa = exp.setVariable("x", a).evaluate();
        double fb = exp.setVariable("x", b).evaluate();
        if (fa * fb > 0) {
            throw new Exception("| No hay raíz en este intervalo");
        } else if (fa * fb == 0) {
            if (fa == 0) {
                throw new Exception("| a es la raíz de la funcion");
            } else {
                throw new Exception("| b es la raíz de la funcion");
            }
        }
        return false;
    }
}
