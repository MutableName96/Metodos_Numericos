package com.mycompany.metodosu5;

import java.util.Scanner;

public class MetodosU5 {

    static Scanner valor = new Scanner(System.in);
    static boolean o = true;
    static int tam = 0;
    static double[] x = null;
    static double[] y = null;
    static int derivada;
    static double sol;
    static double sol2;
    static double h;
    static double k;
    
    public static void main(String[] args) {
        System.out.println("---BIENVENIDO---");
        int opcion = 0;

        do {
            try {
                System.out.println("-----MENÚ-----");
                System.out.println("0. Salir   ");
                System.out.println("1. Diferencia numerica");
                System.out.println("2. Derivada por interpolacion de Newton");
                System.out.println("3. Datos irregularmente espaciados(Lagrange)");
                System.out.print("Seleccione una opción: ");
                opcion = Integer.parseInt(valor.nextLine());

                switch (opcion) {
                    case 1:
                        cargarDatos();
                        difNumerica();
                        break;
                    case 2:
                        cargarDatos();
                        derivNewton();
                        break;
                    case 3:
                        cargarDatos();
                        datosIrreg();
                        break;
                    case 0:
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
                        break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Ha ocurrido un error. Por favor, ingrese una opción válida.");
            }
        } while (opcion != 0);
    }
    ////////////////////////////////////////////////////IRREGULARMENTE ESPACIADOS//////////////////////////////////////////////////////////////////////
    
    public static void datosIrreg(){
    
        if (derivada == x[0] || derivada == x[1] || derivada<x[1]) {
            //k=(derivada-x[0])/h;
            sol = (y[0] *((2*derivada-x[1]-x[2])/((x[0]-x[1])*(x[0]-x[2]))))
                 +(y[1] *((2*derivada-x[0]-x[2])/((x[1]-x[0])*(x[1]-x[2])))) 
                 +(y[2] *((2*derivada-x[0]-x[1])/((x[2]-x[0])*(x[2]-x[1]))));

            System.out.println("Primera derivada: "+sol);
            /*sol2=(1/(h*h))*(y[2]-2*y[1]+y[0]);
            System.out.println("Segunda derivada: "+sol2);*/
            valor.nextLine();
        }
        
        if (derivada > x[1] && derivada <= x[tam - 1]) {
             
            int a = 0, d = 0,b=0;
            for (int i = 1; i < x.length; i++) {
                double q = x[i];
                if (derivada > x[i] && derivada < x[i + 1]) {
                    a = i - 1;
                    b = i;
                    d = i + 1;
                    k=(derivada-x[a])/h;
                }
                if (derivada == x[i]) {
                    a = i - 1;
                    b=i;
                    d = i + 1;
                    k=(derivada-x[a])/h;
                }
            }
            sol = (y[a] *((2*derivada-x[b]-x[d])/((x[a]-x[b])*(x[a]-x[d]))))
                 +(y[b] *((2*derivada-x[a]-x[d])/((x[b]-x[a])*(x[b]-x[d])))) 
                 +(y[d] *((2*derivada-x[a]-x[b])/((x[d]-x[a])*(x[d]-x[b]))));
            //System.out.println(1/h+"..."+y[a]+"..."+y[b]+"..."+y[d]+"..."+k);
            System.out.println("Primera derivada: " + sol);
            sol2=(1/(h*h))*(y[d]-2*y[b]+y[a]);
            System.out.println("Segunda derivada: "+sol2);
            valor.nextLine();
        }

        
    }
    
////////////////////////////////////////////////////DERIVADA POR INTERPOLACION DE NEWTON//////////////////////////////////////////////////////////////////////
    public static void derivNewton() {

        if (derivada == x[0] || derivada == x[1] || derivada == x[2] || derivada<x[1]) {
            k=(derivada-x[0])/h;
            sol = (1/h)*((y[1]-y[0])+((2*k-1)/2)*(y[2]-2*y[1]+y[0]));
            System.out.println("Primera derivada: "+sol);
            sol2=(1/(h*h))*(y[2]-2*y[1]+y[0]);
            System.out.println("Segunda derivada: "+sol2);
            valor.nextLine();
        }
        
        if (derivada > x[1] && derivada <= x[tam - 1]) {
             
            int a = 0, d = 0,b=0;
            for (int i = 1; i < x.length; i++) {
                double q = x[i];
                if (derivada > x[i] && derivada < x[i + 1]) {
                    a = i - 1;
                    b = i;
                    d = i + 1;
                    k=(derivada-x[a])/h;
                }
                if (derivada == x[i]) {
                    a = i - 1;
                    b=i;
                    d = i + 1;
                    k=(derivada-x[a])/h;
                }
            }
            sol = (1/h)*((y[b]-y[a])+((2*k-1)/2)*(y[d]-2*y[b]+y[a]));
            //System.out.println(1/h+"..."+y[a]+"..."+y[b]+"..."+y[d]+"..."+k);
            System.out.println("Primera derivada: " + sol);
            sol2=(1/(h*h))*(y[d]-2*y[b]+y[a]);
            System.out.println("Segunda derivada: "+sol2);
            valor.nextLine();
        }

       /* if (derivada == x[tam - 1]) {
            sol = (y[derivada] - y[derivada - 1]) / h;
            System.out.println("Solución: " + sol);
            valor.nextLine();
        }*/

    }
////////////////////////////////////////////////////CARGAR DATOS//////////////////////////////////////////////////////////////////////
    public static void cargarDatos() {

        do {
            System.out.println("Cuantas iteraciones tiene su tabla??");

            String p = valor.nextLine();

            try {
                tam = Integer.parseInt(p);
                o = false;

            } catch (NumberFormatException e) {

            }
        } while (o == true);

        if (tam > 1) {
            x = new double[tam];
            y = new double[tam];
            for (int i = 0; i < tam; i++) {
                System.out.println("");
                System.out.print("x" + "[" + i + "]");
                x[i] = Double.parseDouble(valor.nextLine());
                System.out.print("y" + "[" + i + "]");
                y[i] = Double.parseDouble(valor.nextLine());
            }
            h = x[1] - x[0];
            if (h < 0) {
                h = h * (-1);
            }
            System.out.println("De cuál 'x' desea hallar la derivada");

            derivada = Integer.parseInt(valor.nextLine());
            
        }
    }
////////////////////////////////////////////////////DIFERENCIA NUMERICA//////////////////////////////////////////////////////////////////////
    public static void difNumerica() {

        if (derivada == x[0]) {
            sol = (y[derivada + 1] - y[derivada]) / h;
            System.out.println("Solución: " + sol);
            valor.nextLine();
        }

        if (derivada > x[0] && derivada < x[tam - 1]) {
            int a = 0, d = 0;
            for (int i = 1; i < x.length; i++) {
                double q = x[i];
                if (derivada > x[i] && derivada < x[i + 1]) {
                    a = i;
                    d = i + 1;

                }
                if (derivada == x[i]) {
                    a = i - 1;
                    d = i + 1;

                }
            }
            sol = (y[d] - y[a]) / (x[d] - x[a]);
            System.out.println("Solución: " + sol);
            valor.nextLine();
        }

        if (derivada == x[tam - 1]) {
            sol = (y[derivada] - y[derivada - 1]) / h;
            System.out.println("Solución: " + sol);
            valor.nextLine();
        }
    }
}
