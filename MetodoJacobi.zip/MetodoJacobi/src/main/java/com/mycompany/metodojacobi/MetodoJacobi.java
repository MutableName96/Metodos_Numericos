package com.mycompany.metodojacobi;

import java.util.Scanner;
/**
 *
 * @author Tonin
 */
public class MetodoJacobi {

    int n = 3, k = 1, maxIteraciones;

    double x = 0, y = 0, z = 0, Tol;

    boolean bandera = false;

    double[][] A = new double[n][n];
    double[] b = new double[n];
    double[] inicial = new double[n];
    Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        MetodoJacobi metodo = new MetodoJacobi();
        metodo.Matriz();
        metodo.Metodo();
        metodo.Datos();
    }

    void Matriz() {
        do {
            System.out.println("\nIngrese los Coeficientes de la Matriz de Diagonal Mayor:");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.print("A[" + (i + 1) + "][" + (j + 1) + "]: ");
                    A[i][j] = scanner.nextDouble();
                }
            }

            System.out.println("\nIngrese los resultados del sistema de ecuaciones (Constantes):");
            for (int i = 0; i < n; i++) {
                System.out.print("b[" + (i + 1) + "]: ");
                b[i] = scanner.nextDouble();
            }

            System.out.println("\nIngrese los valores inciales (X, Y, Z):");
            System.out.print("X: ");
            x = scanner.nextDouble();
            System.out.print("Y: ");
            y = scanner.nextDouble();
            System.out.print("Z: ");
            z = scanner.nextDouble();

            inicial[0] = x;
            inicial[1] = y;
            inicial[2] = z;

            System.out.println("\n Metodo Jacobi ");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.print("[" + A[i][j] + "]");

                }
                System.out.print("= [" + b[i] + "]\n");
            }

            System.out.println("\n  1.- Continuar   2.- Reinciar Matriz");

            if (scanner.nextInt() == 1) {
                bandera = true;
            }

        } while (bandera == false);

        System.out.println("\nIngresa las Iteraciones maximas que deseas ejecutar: ");
        maxIteraciones = scanner.nextInt();

        System.out.println("\nIngresa el valor tolerado: ");
        Tol = scanner.nextDouble();

        bandera = false; 
    }

    void Datos() {
        System.out.println("");
        System.out.println("");
        System.out.println("\n Solucion aproximada de X,Y,Z:");
        System.out.printf("X: " + String.format("%.4f%n", inicial[0]));
        System.out.printf("Y: " + String.format("%.4f%n", inicial[1]));
        System.out.printf("Z: " + String.format("%.4f%n", inicial[2]));
    }

    void Metodo() {
        while (bandera == false && k < maxIteraciones) {

          
            x = (b[0] - (A[0][1] * inicial[1]) - (A[0][2]) * inicial[2]) / A[0][0];
            y = (b[1] - (A[1][0] * inicial[0]) - (A[1][2]) * inicial[2]) / A[1][1];
            z = (b[2] - (A[2][0] * inicial[0]) - (A[2][1]) * inicial[1]) / A[2][2];

            System.out.println("");
            System.out.println("");
            System.out.println("\nNumero de iteracion: " + k);
            System.out.printf("X" + k + ": " + String.format("%.4f%n", x));
            System.out.printf("Y" + k + ": " + String.format("%.4f%n", y));
            System.out.printf("Z" + k + ": " + String.format("%.4f%n", z));

            Converge(x, y, z, Tol);

            k++;

            inicial[0] = x;
            inicial[1] = y;
            inicial[2] = z;
        }
    }

    void Converge(double x, double y, double z, double Tol) {
        double ErrorX = Math.abs((x - inicial[0]) / x);
        double ErrorY = Math.abs((y - inicial[1]) / y);
        double ErrorZ = Math.abs((z - inicial[2]) / z);
        
        if (ErrorX < Tol && ErrorY < Tol && ErrorZ < Tol) {
            bandera = true;
        }

    }
}
