/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.metodo_muller;

import java.util.Scanner;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

/**
 *
 * @author Tonin
 */
public class Metodo_Muller {

    public static void main(String[] args) {
        Muller();
    }
    /*
    Addition: 2 + 2
    Subtraction: 2 - 2
    Multiplication: 2 * 2
    Division: 2 / 2
    Exponentation: 2 ^ 2
    Unary Minus,Plus (Sign Operators): +2 - (-2)
    Modulo: 2 % 2
    
    
    
    
    */
    
    static public void Muller() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese una funcion F(x): ");
        String function = scanner.nextLine();
        Expression func = new ExpressionBuilder(function).variable("x").build();

        System.out.println("Ingrese la prima de su funfcion f(x)': ");
        String dervfunc = scanner.nextLine();
        /**/
        Expression dervFuncExpression = new ExpressionBuilder(dervfunc).variable("x").build();

        System.out.println("Introdsca 3 puntos: ");
        
        System.out.println("Proponga un valor x0: ");
        double x0 = scanner.nextDouble();

        System.out.println("Proponga un valor x1: ");
        double x1 = scanner.nextDouble();

        System.out.println("Proponga un valor x2: ");
        
        double x2 = scanner.nextDouble();

        double x3;//nuevo punto
        double h0,h1,d0,d1,a,b,c;
        double den, raiz;
        
        System.out.printf("%-15s %-20s %-15s\n", "Raíz", "Función Evaluada", "Error (%)");

        do {
            h0 = x1 - x0;
            h1 = x2 - x1;

            func.setVariable("x", x0);
            double fx0 = func.evaluate();
            func.setVariable("x", x1);
            double fx1 = func.evaluate();
            func.setVariable("x", x2);
            double fx2 = func.evaluate();
            double  error;

            d0 = (fx1 - fx0) / h0;
            d1 = (fx2 - fx1) / h1;

            a = (d1 - d0) / (h1 + h0);
            b = a * h1 + d1;
            c = fx2;

            raiz = Math.sqrt(b * b - 4.0 * a * c);

            if (Math.abs(b + raiz) > Math.abs(b - raiz)) {
                den =  b+ raiz;
            } else {
                den = b - raiz;
            }
            
            x3 = x2 - 2 * c / den;
            
            error = (Math.abs((x3 - x2) / x3)) * 100; 
            
            System.out.printf("%-15.4E %-20.4E %-15.4E\n", x3, func.setVariable("x", x3).evaluate(), error);

            x0 = x1;
            x1 = x2;
            x2 = x3;
        } while (Math.abs(func.setVariable("x", x3).evaluate()) > 0.000000001);
        System.out.println("");
        System.out.printf("La raíz es: %.4E\n", x3);
}
   
    
}
