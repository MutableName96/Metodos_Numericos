
package ejercicios.u2.metodonewtonrhapson;

import java.text.DecimalFormat;
import java.util.Scanner;
import lombok.Data;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.DecompositionSolver;
import org.apache.commons.math3.linear.LUDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.nfunk.jep.JEP;
import org.nfunk.jep.Node;
import org.nfunk.jep.function.NaturalLogarithm;

@Data
public class matriz {
    Scanner leer= new Scanner(System.in);
    private int iteraciones=0;
    private JEP ecuaciones[][] = new JEP[3][3];
    private JEP derivadas[][] = new JEP[3][3];
    private double ecEval[][]= new double[3][3];
    
    private double independiente[] = new double[3];
    private double variables[] = new double[3];
    private double h[]= new double[3];
    private double valores[]=new double[3];
    
    private DecimalFormat formato=new DecimalFormat("#.###");
    
    public matriz(){
        
        for (int i = 0; i < ecuaciones.length; i++) {
            for (int j = 0; j < ecuaciones[i].length; j++) {
                ecuaciones[i][j] = new JEP();
                ecuaciones[i][j].addStandardConstants();
                ecuaciones[i][j].addStandardFunctions();
                ecuaciones[i][j].setAllowUndeclared(true);
                ecuaciones[i][j].setImplicitMul(true);
                ecuaciones[i][j].addFunction("ln", new NaturalLogarithm());     
            }
        }
        for (int i = 0; i < derivadas.length; i++) {
            for (int j = 0; j < ecuaciones[i].length; j++) {
                derivadas[i][j] = new JEP();
                derivadas[i][j].addStandardConstants();
                derivadas[i][j].addStandardFunctions();
                derivadas[i][j].setAllowUndeclared(true);
                derivadas[i][j].setImplicitMul(true);
                derivadas[i][j].addFunction("ln", new NaturalLogarithm());           
            } 
        }
        pedirDatos();
    }
    
    public void pedirDatos(){
        String x;
        System.out.println("");   
        System.out.println(" Terminos De la Ecuacion");
        for (int i = 0; i < ecuaciones.length; i++) {
            for (int j = 0; j < ecuaciones.length; j++) {
                if(j==0){x="x";}
                else if(j==1){x="y";}
                else{x="z";}
                        System.out.println("");   

                System.out.println("Ingresa el valor de la matrix con cuidadito"+x+" "+(i+1));
                        System.out.println("");   

                ecuaciones[i][j].parseExpression(leer.nextLine());   
            }
                    System.out.println("");   

            System.out.println("Ingresa el valor del termino independiente con la ecuacion igualada a 0");
            independiente[i]=Double.parseDouble(leer.nextLine());
                    System.out.println("");   

       }
        System.out.println("");   
        System.out.println("Diferenciales");
        for (int i = 0; i < derivadas.length; i++) {
            for (int j = 0; j < ecuaciones.length; j++) {
                x = switch (j) {
                    case 0 -> "x";
                    case 1 -> "y";
                    default -> "z";
                };
                        System.out.println("");   

                System.out.println("Ingresa el valor "+x+" de la derivada "+(i+1));
                derivadas[i][j].parseExpression(leer.nextLine()); 
            }
        }
        System.out.println("Ahora ingresaremos los valores iniciales con los que empezaran x0, y0 y z0:");
        for (int i = 0; i < variables.length; i++) {       
            x = switch (i) {
                case 0 -> "x";
                case 1 -> "y";
                default -> "z";
            };
            System.out.println("Ingresa el valor inicial de "+x+":");
            variables[i]=leer.nextDouble();
        }
    }
    
    public void calcularValores(){
        double valor=0;
        for (int i = 0; i < ecuaciones.length; i++) {
            for (int j = 0; j < ecuaciones.length; j++) {
            
                switch (j) {
                    case 0 -> {derivadas[i][j].addVariable("x",variables[0]);
                               ecuaciones[i][j].addVariable("x",variables[0]);
                    }
                    case 1 -> {derivadas[i][j].addVariable("y",variables[1]);
                               ecuaciones[i][j].addVariable("y",variables[1]);
                    }
                    default -> {derivadas[i][j].addVariable("z",variables[2]);
                                ecuaciones[i][j].addVariable("z",variables[2]);
                    }
                }
                valor+=(ecuaciones[i][j].getValue());      
                ecEval[i][j]=derivadas[i][j].getValue();
            }
            
            valores[i]=(-1)*(Double.parseDouble(formato.format(valor))+independiente[i]);
            valor=0;
        }
    }
    public void calcularH(){
        int contadorH=0;
        System.out.println("");
        RealMatrix matriz= MatrixUtils.createRealMatrix(ecEval);
        DecompositionSolver solver = new LUDecomposition(matriz).getSolver();
        if (solver.isNonSingular()) {
            RealMatrix inversa = solver.getInverse();
            ecEval=inversa.getData();
            RealVector vectorObj = new ArrayRealVector(valores);
            RealVector resultado = inversa.operate(vectorObj);            
            h=resultado.toArray();
            for (int i = 0; i < h.length; i++) {
                h[i]=Double.parseDouble(formato.format(h[i]));
                 if(h[i]==0){
                     contadorH++;
                }
            }
            if(contadorH==3){
                System.out.println("Numero de iteraciones: "+iteraciones);
                String y;
                for (int i = 0; i < ecuaciones.length; i++) {
                    y = switch (i) {
                        case 0 -> "x";
                        case 1 -> "y";
                        default -> "z";
                    };
                    System.out.println(y+" "+variables[i]);
                }
                System.exit(0);
            }    
        } else {
            System.out.println("Error la matriz no es invertible.");
            System.exit(0);
        }
    }
    public void actualizarVar(){   
        System.out.println("Actualizando el valor de las variables");
        for (int i = 0; i < variables.length; i++) {
            variables[i]+=h[i];
        }
        System.out.println("Se actualizaron los valores de X, Y, Z ");
    }
    public void calcular(){
        while(true){
            iteraciones++;
            calcularValores();
            mostrarUNO();
            calcularH();
            mostrarDos();
            actualizarVar();
        }
    }
    
    public void mostrarUNO(){
        String x;
        System.out.println("Los datos que tenemos en esta iteracion son...");
        for (int i = 0; i < ecuaciones.length; i++) {
            x = switch (i) {
                    case 0 -> "x";
                    case 1 -> "y";
                    default -> "z";
            };
            System.out.print(x+" = "+variables[i]+" -> |");
            for (int j = 0; j < ecEval.length; j++) {
                System.out.print(ecEval[i][j]+" ");
            }
            x = switch (i) {
                    case 0 -> "h1";
                    case 1 -> "h2";
                    default -> "h3";
            };
            System.out.print("|  | "+x+" |");
            if (i!=1){System.out.print("   ");}else{System.out.print(" = ");}
            System.out.print("| "+valores[i]+" |\n");
        }    
    }
    
    public void mostrarDos(){
        System.out.println("");
        for (int i = 0; i < ecEval.length; i++) {
            System.out.print("h"+(i+1)+" |");
            for (int j = 0; j < ecEval[i].length; j++) {
                System.out.print(ecEval[i][j]+" ");
            }
            System.out.print(" | "+valores[i]+" | ");
            if(i==1){System.out.print("=");}else{
                System.out.print(" ");
            }
            System.out.print(" |"+h[i]+"| \n");
        }
    }
    public void mostrarSistema(){
        for (int i = 0; i < ecuaciones.length; i++) {
            for (int j = 0; j < ecuaciones.length; j++) {
                Node topNode = ecuaciones[i][j].getTopNode();
                
                String expression = topNode.toString();
                System.out.print(expression+"    ");
            }
            if(i==1)System.out.print(" = ");
            if(i!=1)System.out.print(" ");
            for (int j = 0; j < ecuaciones.length; j++) {
                System.out.print(derivadas[i][j]+" ");
            }
            System.out.println(" ");
        }
    }
   
}
