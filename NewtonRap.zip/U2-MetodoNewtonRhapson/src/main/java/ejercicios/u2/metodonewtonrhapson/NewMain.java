
package ejercicios.u2.metodonewtonrhapson;

public class NewMain {

    public static void main(String[] args) {
        matriz matrix= new matriz();
        matrix.calcular();
    }
    
}
